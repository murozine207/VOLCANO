<?php

include('db_connect.php');
$full_names=$_POST['fullname'];
$contact=$_POST['contact'];
$email_address=$_POST['email'];
$password=$_POST['password'];

$sql = "INSERT INTO volcanouser (full_names,contact,email_address,password)
VALUES ('$full_names','contact', '$email_address', '$password')";

if ($conn->query($sql) === TRUE) {
  echo "YOU ARE REGISTERED IN THE SYSTEM";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}


$conn->close();


?>
<br><br><a href='book.php'>book Ticket</a>