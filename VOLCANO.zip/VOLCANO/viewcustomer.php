<?php

// Create connection
$conn = new mysqli('localhost', 'root', '', 'volcano');
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM customers";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table border=1><tr><th>customer_id</th><th>customer_names</th><th>customer_contact</th><th>customer_address</th>email</th><th>password</th><th>Action</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["customer_id"]. "</td><td>" . $row["customer_names"]. " </td><td>" . $row["customer_contact"]."</td><td> ". $row["customer_address"]."</td></tr>". $row["email"]."</td><td> ". $row["password"]."</td><td> ";
    }
    echo "</table>";
}
 else {
  echo "0 results";
}
$conn->close();
?>