<!DOCTYPE html>
<html lang="en">
<head>
<title>www.volcanoexpress.com</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<style>
* {
  box-sizing: border-box;
  font-family: Arial, Helvetica, sans-serif;
	margin: 0;
}

body {
background-image: url("iman.JPG");
 box-sizing: border-box;
  font-family: sans-serif;
	margin: 0;
	width:100%;
}

/* Style the top navigation bar */
.topnav {
  overflow: hidden;
  background-color: blue;
}

/* Style the topnav links */
.topnav a {
  float: left;
  display: inline-block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

/* Change color on hover */
.topnav a:hover {
  background-color:black;
  color: white;
}
.topnav input[type=text] {
  float: right;
  padding: 6px;
  border: none;
  margin-top: 8px;
  margin-right: 16px;
  font-size: 17px;
/* Style the content */
.content a{
  float: center;
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}
.content a:hover {
  background-color: #333;
  color: blue;
  text-align: center;
  }
/* Style the footer */
.footer {
  background-color: white;
 height: 200px;
}
 .rosine{
        background-color: #ffeecc;
        color: white;
        font-size: 17px;
        text-align:justify;
        border: 0;
        border-radius: 4px;
  }
	.welcome 
	{
		position: relative;
		text-align: center;			
	}
  #rose{
    font-size: 24px;
  
  }
	
</style>
<body>
 <div class="topnav">
  <a href="home1.php">HOME</a>
  <a href="contact us.php">contact us</a>
  <a href="policies and terms.php">policies and terms</a>
  <a href="login.php">login</a>
  <a href="image.php">image</a>
  <a href="price and duration.php">price and duration</a>
	</div>
  <center>
 
<style>
body {
  font-family: Arial;
}

input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=number], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=submit] {
  width: 100%;
  background-color: #04AA6D;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

div.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
</style>

<div class="container">
  <form action="/action_page.php">
    <label for="fname">First Name</label>
    <input type="text" id="fname" name="firstname" placeholder="Your name..">

    <label for="lname">Last Name</label>
    <input type="text" id="lname" name="lastname" placeholder="Your last name..">

    <label for="contact">Contact</label>
     <input type="number" id="contact" name="contact" placeholder="your phone number..">
  
   <label for="from">from</label>
    <input type="text" id="from" name="from" placeholder="from where..">
     <label for="to">to</label>
    <input type="text" id="to" name="to" placeholder="going to....">
    <input type="submit" value="Submit">
  </form>
</div>

</body>
</html>
