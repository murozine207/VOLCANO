<?php
include 'booking.php';
$fname=$_POST['FirstName'];

$lname=$_POST['LastName'];

//$email=$_POST['email'];

$phoneNumber=$_POST['MobileNumber'];

$gender=$_POST['Gender'];

$departure=$_POST['leaving_from'];

$destination=$_POST['going_to'];

$payment_date=$_POST['Paymentdate'];

$payment_mon=$_POST['Payment_Month'];

$tpayment_year=$_POST['payment_year'];
$conn= new MySQLi('localhost','root','','volcano');

if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$sql = "INSERT INTO booking (fname,lname,phoneNumber,gender,departure,destination,payment_date,payment_mon,payment_year)
VALUES ('$fname','$lname','$phoneNumber','$gender','$departure','$destination','$payment_date','$payment_mon','$tpayment_year')";

if (mysqli_query($conn, $sql)) {
  echo "<h1>Your Request Accepted</h1>";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);

 ?>