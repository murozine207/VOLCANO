<?php

include 'config.php';
error_reporting(0);
if(isset($_POST['submit'])){
    $Username = $_POST['username'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];
    

    if($password == $cpassword){
          $sql = "INSERT INTO customer(customer_id,customer_names,customer_contact,customer_address,password)VALUES('',\"$Username\",\"$phone\",\"$address\",\"$password\")";
        $result = mysqli_query($conn, $sql);
        if($result){
            echo "<script>alert('successfully registered')</script>";
        }else{
            echo 'failed to register' . mysqli_error($conn);  
        }
      }else{
          echo "<script>alert('password doesnt match')</script>";
      }
  

}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Register</title>
</head>
<body>
    <div class="container">
        <form class="login-email" action="" method="POST">
            <p class="login-text" style="font-size: 2rem; font-weight: 800;">Register Customer</p>
            <div class="input-group">
                <input type="text" placeholder="Username" name="username" value="" required>
            </div>
            <div class="input-group">
                <input type="text" placeholder="tel" name="phone" value="" required>
            </div>
       
            <div class="input-group">
                <input type="text" placeholder="Address" name="address" value="" required>
            </div>
            <div class="input-group">
                <input type="password" placeholder="password" name="password" value="" required>
            </div>
            <div class="input-group">
                <input type="password" placeholder="confirm password" name="cpassword" value="" required>
            </div>
            <div class="input-group">
                <button name="submit" class="btn">Register</button>
            </div>
        </form>
    </div>
</body>
</html>