<?php

// Create connection
$conn = new mysqli('localhost', 'root', '', 'volcano');
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM priceandpayments";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table border=1><tr><th>payment_id</th><th>booking_id</th><th>amount_paid</th><th>payment_date</th><th>Action</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["payment_id"]. "</td><td>" . $row["booking_id"]. " </td><td>" . $row["amount_paid"]."</td><td> ". $row["payment_date"]."</td></tr>";
    }
    echo "</table>";
}
 else {
  echo "0 results";
}
$conn->close();
?>