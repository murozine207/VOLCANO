<?php

include 'config.php';
error_reporting(0);
if(isset($_POST['submit'])){
    $bus_id = $_POST['bus_id'];
    $driver_id = $_POST['driver_id'];
    $starting_point = $_POST['starting_point'];
    $destination = $_POST['destination'];
    $departure_time = $_POST['departure_time'];
    $estimate_arrivaltime = $_POST['estimate_arrivaltime'];
    $fare_amount = $_POST['fare_amount'];
    $user_id = $_POST['user_id'];


          $sql = "INSERT INTO schedule(schedule_id,bus_id,driver_id,starting_point,destination,departure_time,estimate_arrivaltime,fare_amount,user_id)
          VALUES('',\"$bus_id\",\"$driver_id\",\"$starting_point\",\"$destination\",\"estimate_arrivaltime\",\"fare_amount\",\"user_id\")";"
        $result = mysqli_query($conn, $sql);
        if($result){
            echo 'successfully registered';
        }else{
            echo 'failed to register' . mysqli_error($conn);  
        }
     
      
  


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Register</title>
</head>
<body>
    <div class="container">
        <form class="login-email" action="" method="POST">
            <p class="login-text" style="font-size: 2rem; font-weight: 800;">Register schedule</p>
            <div class="input-group">
                <input type="number" placeholder="bus_id" name="bus_id" value="" required>
            </div>
            <div class="input-group">
                <input type="number" placeholder="driver_id" name="driver_id" value="" required>
            </div>
       
            <div class="input-group">
                <input type="text" placeholder="starting_point" name="starting_point" value="" required>
            </div>
            <div class="input-group">
                <input type="text" placeholder="destination" name="destination" value="" required>
            </div>
            <div class="input-group">
                <input type="time" placeholder="departure_time" name="departure_time" value="" required>
            </div>
            <div class="input-group">
                <input type="time" placeholder="estimate_arriivaltime" name="estimate_arrivaltime" value="" required>
            </div>
           
            <div class="input-group">
                <input type="char" placeholder="fare_amount" name="fare_amount" value="" required>
            </div>
            <div class="input-group">
                <input type="number" placeholder="user_id" name="user_id" value="" required>
            </div>
            <div class="input-group">
                <button name="submit" class="btn">Register</button>
            </div>
        </form>
    </div>
</body>
</html>