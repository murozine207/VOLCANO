<?php
$conn=mysqli_connect('localhost','rosine','gisozi','volcano');


?>