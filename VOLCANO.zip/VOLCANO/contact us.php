
<!DOCTYPE html>
<html lang="en">
<head>
<title>www.volcanoexpress.com</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<style>
* {
  box-sizing: border-box;
  font-family: Arial, Helvetica, sans-serif;
}

body {

 box-sizing: border-box;
  font-family: Arial, Helvetica, sans-serif;
}

/* Style the top navigation bar */
.topnav {
  overflow: hidden;
  background-color: #333;
}

/* Style the topnav links */
.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

/* Change color on hover */
.topnav a:hover {
  background-color: #ddd;
  color: white;
}
.topnav input[type=text] {
  float: right;
  padding: 6px;
  border: none;
  margin-top: 8px;
  margin-right: 16px;
  font-size: 17px;
}

/* Style the content */
.content {
  background-image: url("back3.file");
  padding: 10px;
  background-repeat: no-repeat;
background-size: cover; 
  height: 550px; /* Should be removed. Only for demonstration */
}
.content a{
  float: center;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}
.content a:hover {
  background-color: #ddd; 
  color: blue;
  text-align: center;
  }
/* Style the footer */
.footer {
  background-color: #333;
  padding: 10px;
}
.footer p {
        font-family: initial;
        color: blue;
        font-size: 17px;
  }
</style>
<body background="conta.jpg"; background-size="cover"; background-repeat="no-repeat";>
 <center><div>
  <a href="home1.php"><HOME</font></a>
  <a href="book.php"><book</font></a>
  <a href="policies and terms.php">policies and terms</font></a>
  <a href="image.php">>image</font></a> 
  <a href="login.php">login</font></a>
  <a href="price and duation.php">price and duration</font></a>
<div class="m-logo-wrap">
                <a href="//www.made-in-rwanda.com/" title="volcano express" class="m-logo"></a>
        </div>
<form action="//submit.form" id="ContactUs100" method="post" onsubmit="return ValidateForm(this);">
<script type="text/javascript">
function ValidateForm(frm) {
if (frm.Name.value == "") { alert('Name is required.'); frm.Name.focus(); return false; }
if (frm.FromEmailAddress.value == "") { alert('Email address is required.'); frm.FromEmailAddress.focus(); return false; }
if (frm.FromEmailAddress.value.indexOf("@") < 1 || frm.FromEmailAddress.value.indexOf(".") < 1) { alert('Please enter a valid email address.'); frm.FromEmailAddress.focus(); return false; }
if (frm.Comments.value == "") { alert('Please enter comments or questions.'); frm.Comments.focus(); return false; }
return true; }
</div>
<script>
        var __IS_USER_LOGED__ =  false ;
</script>                <div class="m-header-menu-gap"></div>
</script>
<table style="width:100%;max-width:550px;border:0;" cellpadding="8" cellspacing="0">
<tr> <td>
<label for="Name"><font size="" color="#white">Name:</font></label>
</td> <td>
<input name="Name" type="text" maxlength="60" style="width:100%;max-width:250px;" />
</td> </tr> <tr> <td>
<label for="PhoneNumber"><font size="" color="#white">Phone number:</font></label>
</td> <td>
<input name="PhoneNumber" type="text" maxlength="43" style="width:100%;max-width:250px;" />
</td> </tr> <tr> <td>
<label for="FromEmailAddress"><font size="" color="#white">Email address:</font></label>
</td> <td>
<input name="FromEmailAddress" type="text" maxlength="90" style="width:100%;max-width:250px;" />
</td> </tr> <tr> <td>
<label for="Comments"><font size="" color="#white">Comments:</font></label>
</td> <td>
<textarea name="Comments" rows="7" cols="40" style="width:100%;max-width:350px;"></textarea>
</td> </tr> <tr> <td>
 </font></p>

</td> <td>
<div style="float:right"><a href="https://www.100forms.com" id="lnk100" title="form to email">form to email</a></div>
<input name="skip_Submit" type="submit" value="Submit" />

</td> </tr>
</table>
</form>
</body>
</html>

