-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 16, 2021 at 10:26 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `volcano`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `names` varchar(60) NOT NULL,
  `contact` int(11) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`names`, `contact`, `username`, `password`) VALUES
('admin', 722513854, '123', '123'),
('ADMIN', 5655445, 'rosine@123', '123');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `id` int(11) NOT NULL,
  `schedule_id` varchar(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `numberofseats` int(11) NOT NULL,
  `fare_amount` float NOT NULL,
  `total_amount` float NOT NULL,
  `dateofbooking` datetime NOT NULL,
  `booking_status` datetime NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`id`, `schedule_id`, `customer_id`, `numberofseats`, `fare_amount`, `total_amount`, `dateofbooking`, `booking_status`, `created_at`) VALUES
(2, '0', 0, 783019872, 0, 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2021-08-01 19:03:41'),
(3, '0', 0, 896, 0, -1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2021-08-01 19:05:55'),
(4, '0', 0, 896, 0, -1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2021-08-01 19:09:28'),
(5, '0', 0, 896, 0, -1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2021-08-01 19:10:43'),
(6, '0', 0, 896, 0, -1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2021-08-01 19:11:41'),
(7, '0', 0, 896, 2, -1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2021-08-01 19:16:37'),
(8, '0', 0, 896, 2, -1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2021-08-01 19:17:17'),
(19, '1', 2, 23, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2021-08-04 17:16:26'),
(20, '3', 7, 78, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2021-08-04 17:17:15'),
(21, '3', 1, 54, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2021-08-04 19:34:27'),
(22, '3', 1, 54, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2021-08-04 19:35:30'),
(23, '3', 1, 54, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2021-08-04 19:36:44');

-- --------------------------------------------------------

--
-- Table structure for table `bus`
--

CREATE TABLE `bus` (
  `bus_id` int(11) NOT NULL,
  `bus_number` varchar(12) NOT NULL,
  `bus_platenumber` varchar(15) NOT NULL,
  `bus_type` varchar(11) NOT NULL,
  `capacity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bus`
--

INSERT INTO `bus` (`bus_id`, `bus_number`, `bus_platenumber`, `bus_type`, `capacity`) VALUES
(1, '100', 'RAB123V', '0', 24),
(2, '101', 'RAF243V', 'Hundai', 25),
(3, '4543', 'RAB 678H', 'Ritco', 60),
(4, '100', 'RAB123V', 'Toyota', 25);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL,
  `customer_names` varchar(50) NOT NULL,
  `customer_contact` varchar(20) NOT NULL,
  `customer_address` varchar(25) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `customer_names`, `customer_contact`, `customer_address`, `email`, `password`) VALUES
(1, 'eich', '0788568936', '', 'rosine@gmail.com', 'rosine'),
(2, 'umuhire rosine', '0788568936', 'Kigali', '', 'me'),
(3, 'cyiza', 'mugabo', 'tumba', '', 'tu'),
(4, 'cyiza', '0783019872', 'finest', '', 'ere');

-- --------------------------------------------------------

--
-- Table structure for table `driver`
--

CREATE TABLE `driver` (
  `driver_id` int(11) NOT NULL,
  `driver_name` varchar(10) NOT NULL,
  `driver_contact` varchar(15) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `driver`
--

INSERT INTO `driver` (`driver_id`, `driver_name`, `driver_contact`, `user_id`) VALUES
(1, 'driverName', '0788568936', 2147483647),
(2, 'Rose', '0788564218', 2147483647),
(3, 'Rosine', '0722565871', 2147483647),
(4, 'cyusa', '0783019827', 12);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `username` char(10) NOT NULL,
  `password` varchar(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `fullname`, `username`, `password`) VALUES
(1, 'rosine', 'murozine20', 'gisozi'),
(2, 'ihirwea line', 'kirezi2210', '2345'),
(3, 'umuhire rosine', 'murozine20', '2trul7p9;'),
(4, 'adrien kamaka', 'nteziryayo', '13235479'),
(5, 'adrien kamaka', 'nteziryayo', '5222'),
(6, 'adrien kamaka', 'nteziryayo', '5222'),
(7, 'adrien kamaka', 'nteziryayo', '5222'),
(8, 'adrien kamaka', 'nteziryayo', '5222'),
(9, 'adrien kamaka', 'murozine20', '124554689'),
(10, 'umuhire rosine', 'murozine20', '123456'),
(11, 'adrien kamaka', 'nteziryayo', '121324457'),
(12, 'umuhire rosine', 'murozine20', '3568799-0'),
(13, 'umuhire rosine', 'mwisemarie', 'werfrtyku'),
(14, 'umuhire rosine', 'murozine20', 'tvvtvtbgb'),
(15, 'umuhire rosine', 'murozine20', 'tvvtvtbgb'),
(16, 'umuhire rosine', 'murozine20', 'gggg'),
(17, 'umuhire rosine', 'murozine20', 'gggg'),
(18, 'umuhire rosine', 'murozine20', 'gggg');

-- --------------------------------------------------------

--
-- Table structure for table `priceandpayments`
--

CREATE TABLE `priceandpayments` (
  `payment_id` int(11) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `amount_paid` float NOT NULL,
  `payment_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `priceandpayments`
--

INSERT INTO `priceandpayments` (`payment_id`, `booking_id`, `amount_paid`, `payment_date`) VALUES
(1, 23, 2600, '0000-00-00'),
(2, 12, 2300, '0000-00-00'),
(3, 4, 6500, '2021-08-08'),
(4, 4, 6500, '2021-08-08'),
(5, 23, 0, '0000-00-00'),
(6, 56, 8900, '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `price_and_duration`
--

CREATE TABLE `price_and_duration` (
  `FROM` varchar(10) NOT NULL,
  `TO` varchar(15) NOT NULL,
  `PRICE` int(11) NOT NULL,
  `OPENINGTIME` time NOT NULL,
  `CLOSINGTIME` time NOT NULL,
  `CONTACT` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `price_and_duration`
--

INSERT INTO `price_and_duration` (`FROM`, `TO`, `PRICE`, `OPENINGTIME`, `CLOSINGTIME`, `CONTACT`) VALUES
('kigali', 'huye', 2600, '07:22:34', '17:22:34', 784771872),
('kigali', 'rubavu', 3400, '06:22:34', '13:22:34', 784771872),
('from', 'to', 45364, '00:00:00', '00:00:00', 8909867),
('from', 'to', 45364, '03:33:43', '00:02:42', 8909867),
('', '', 0, '00:00:00', '00:00:00', 0),
('gisagara', 'nyamagabe', 300, '09:00:00', '14:00:00', 788230853),
('huye', 'gisagara', 500, '05:14:00', '17:14:00', 2147483647),
('', '', 0, '00:00:00', '00:00:00', 0),
('', '', 0, '00:00:00', '00:00:00', 0),
('', '', 0, '00:00:00', '00:00:00', 0),
('', '', 0, '00:00:00', '00:00:00', 0),
('', '', 0, '00:00:00', '00:00:00', 0),
('', '', 0, '00:00:00', '00:00:00', 0),
('', '', 0, '00:00:00', '00:00:00', 0),
('', '', 0, '00:00:00', '00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `schedule_id` int(11) NOT NULL,
  `bus_id` int(11) NOT NULL,
  `driver_id` int(11) NOT NULL,
  `starting_point` varchar(30) NOT NULL,
  `destination` varchar(30) NOT NULL,
  `departure_time` time NOT NULL,
  `estimate_arrivaltime` time NOT NULL,
  `fare_amount` float NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`schedule_id`, `bus_id`, `driver_id`, `starting_point`, `destination`, `departure_time`, `estimate_arrivaltime`, `fare_amount`, `user_id`) VALUES
(1, 1, 23, 'huye', 'kigali', '06:00:00', '09:47:19', 2600, 12);

-- --------------------------------------------------------

--
-- Table structure for table `volcanouser`
--

CREATE TABLE `volcanouser` (
  `user_id` int(11) NOT NULL,
  `full_names` varchar(60) NOT NULL,
  `contact` int(11) NOT NULL,
  `email_address` varchar(20) NOT NULL,
  `password` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `volcanouser`
--

INSERT INTO `volcanouser` (`user_id`, `full_names`, `contact`, `email_address`, `password`) VALUES
(1, '', 784772982, '', 'mn'),
(2, '', 87563344, '', 'hu'),
(3, 'eddy kayi', 87563344, 'mwisemarierose@gmail', 'hu'),
(4, '', 0, '', '123456'),
(5, '', 0, '', '123456'),
(6, '', 0, '', '123456'),
(7, '', 0, '', '25255'),
(8, '', 0, '', '25255'),
(9, '', 0, '', '25255'),
(10, '', 0, '', '25255'),
(11, 'nkurikiye edward', 0, 'nkurikiye@gmail.com', '25255'),
(12, '', 0, '', '12345'),
(13, '', 0, '', '12345'),
(14, '', 0, '', '12345'),
(15, '', 0, '', '212'),
(16, '', 0, '', 'dfghjk'),
(17, '', 0, '', '3r5689');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bus`
--
ALTER TABLE `bus`
  ADD PRIMARY KEY (`bus_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `driver`
--
ALTER TABLE `driver`
  ADD PRIMARY KEY (`driver_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priceandpayments`
--
ALTER TABLE `priceandpayments`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`schedule_id`);

--
-- Indexes for table `volcanouser`
--
ALTER TABLE `volcanouser`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `bus`
--
ALTER TABLE `bus`
  MODIFY `bus_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `driver`
--
ALTER TABLE `driver`
  MODIFY `driver_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `priceandpayments`
--
ALTER TABLE `priceandpayments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `schedule_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `volcanouser`
--
ALTER TABLE `volcanouser`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
