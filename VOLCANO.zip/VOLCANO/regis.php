<?php

include('db_connect.php');
$fullname=$_POST['fullname'];
$email=$_POST['email'];
$password=$_POST['password'];

$sql = "INSERT INTO login (	fullname,username, password)
VALUES ('$fullname', '$email', '$password')";

if ($conn->query($sql) === TRUE) {
  echo "YOU ARE REGISTERED IN THE SYSTEM";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}


$conn->close();


?>
<br><br><a href='book.php'>book Ticket</a>