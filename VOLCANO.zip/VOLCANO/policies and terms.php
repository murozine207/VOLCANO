
<!DOCTYPE html>
<html lang="en">
<head>
<title>www.volcanoexpress.com</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<style>
* {
  box-sizing: border-box;
  font-family: Arial, Helvetica, sans-serif;
}

body {

 box-sizing: border-box;
  font-family: Arial, Helvetica, sans-serif;
}

/* Style the top navigation bar */
.topnav {
  overflow: hidden;
  background-color: #333;
}

/* Style the topnav links */
.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

/* Change color on hover */
.topnav a:hover {
  background-color: #ddd;
  color: black;
}
.topnav input[type=text] {
  float: right;
  padding: 6px;
  border: none;
  margin-top: 8px;
  margin-right: 16px;
  font-size: 17px;
}

/* Style the content */
.content {
.content a{
  float: center;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}
.content a:hover {
  background-color: #ddd;
  color: black;
  text-align: center;
  }
/* Style the footer */
.footer {
  background-color: #333;
  padding: 10px;
}
.footer p {
        font-family: initial;
        color: white;
        font-size: 17px;
  }
</style>
<body>

 <div class="topnav">
  <a href="home1.php">HOME</a>
  <a href="book.php">book</a>
  <a href="contact us.php">contact us</a>
  <a href="image.php">image</a>
    <a href="login.php">login</a>
    <a href="price_and_duration.php">price and duration</a>
	<center> <div class="content">
	<center>
  <table class="rosine"><tr>
  <img src="pol.jpg" style="width:90%">
 <td><p><font color="white" size="5px">
 This Website is expected to help customers in seeking and gathering details about travel, and additionally in seeking and obtaining travel related products and services, and not for some other reason outside these.
This site is a type of marketplace, the commercial center is a stage that encourages web booking, buy of travel bundles and other travel related administrations and services offered by different outsider and third-party administration and service suppliers.p></font></p>
<font color="white" size="5px"> The expressions "we", "us", "our", "bus booking .com" administration and services suppliers on the marketplace are exclusively in charge of the services sold to any client. We serve as delegate between the clients and the administration suppliers. Our stage is the place the administration suppliers showcase their travel related bundles (settlement, occasion bundles, ticketing, and so forth.) and servciess, so as clients can patronise them through us. By making a booking through Ticketbooking.com you go into a lawfully compulsory concurrence with the accommodation supplier or provider at which you book.</font></p>
<p><font color="white" size="5px">
  Cancellation and refund request, if applicable, will be processed as per the policy of the operator / service partner. The cancellation fee and the period will differ for each operator. Please refer to the Refund Policy.
Unless mentioned or stated otherwise, ticket purchases once confirmed are final and are not refundable or changeable. Please check the selected schedule information carefully before check-out. Duplicate transactions are also not refundable because duplicate transactions block other customers from purchasing tickets. There will be no refund for any unused or partly used services.
</font></table></td></tr>
<table>
<td><p><font color="white" size="5px">We welcome any comment or complaint about a supplier, which you make through our website. We may act upon a complaint in our discretion, for the benefit of the body of our members. 
Under 18 years? Sorry, but we deal only with people who are legally able to enter into a binding contract. Please ask someone over 18 to book your travel related good and service on your behalf. If you use our service, you do so in accordance with these terms. If you are unable to accept these terms, your only remedy is to leave our website and stop using the Ticketbooking.com website or app. </font></p></table></td>
<center><div class="footer">
  <p><font <font size="5px" color="#ffffff">2021 Copyright/allright reserved/VOLCANO EXPRESS</font></p>
</div>
</body>
</html>

