<?php

include 'config.php';
error_reporting(0);
if(isset($_POST['submit'])){
    $scheduleid= $_POST['scheduleid'];
    $customerid = $_POST['customerid'];
    $numberofseats= $_POST['numberofseats'];
    $fareamount= $_POST['fareamount'];
    $totalamount= $_POST['totalamount'];
    $dateofbooking= $_POST['dateofbooking'];
    $bookingid= $_POST['bookingid'];
    
          $sql = "INSERT INTO booking(id,schedule_id,customer_id,numberofseats,fare_amount,total_amount,dateofbooking,booking_status)VALUES('',\"$scheduleid\",\"$customerid\",\"$numberofseats\",\"fareamount\",\"totalamount\",\"dateofbooking\",\"bookingid\")";
        $result = mysqli_query($conn, $sql);
        if($result){
            echo "<script>alert('successfully registered')</script>";
        }else{
            echo 'failed to register' . mysqli_error($conn);  
        }
      }
  


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Register</title>
</head>
<body>
    <div class="container">
        <form class="login-email" action="" method="POST">
            <p class="login-text" style="font-size: 2rem; font-weight: 800;">Register booking</p>
            <div class="input-group">
                <input type="text" placeholder="scheduleid" name="scheduleid" value="" required>
            </div>
            <div class="input-group">
                <input type="text" placeholder="customerid" name="customerid" value="" required>
            </div>
       
            <div class="input-group">
                <input type="text" placeholder="numberofseats" name="numberofseats" value="" required>
            </div>
            <div class="input-group">
                <input type="text" placeholder="fareamount" name="fareamount" value="" required>
            </div>
            <div class="input-group">
                <input type="text" placeholder="totalamount" name="totalamount" value="" required>
            </div>
            <div class="input-group">
                <input type="text" placeholder="dateofbooing" name="dateofbooking" value="" required>
            </div>
            <div class="input-group">
                <input type="text" placeholder="bookingid" name="bookingid" value="" required>
            </div>
            <div class="input-group">
                <button name="submit" class="btn">Register</button>
            </div>
        </form>
    </div>
</body>
</html>