
<!DOCTYPE html>
<html lang="en">
<head>
<title>www.volcanoexpress.com</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<style>
* {
  box-sizing: border-box;
  font-family: Arial, Helvetica, sans-serif;
	margin: 0;
}

body {
background-image: url("iman.JPG");
 box-sizing: border-box;
  font-family: sans-serif;
	margin: 0;
	width:100%;
}

/* Style the top navigation bar */
.topnav {
  overflow: hidden;
  background-color: blue;
}

/* Style the topnav links */
.topnav a {
  float: left;
  display: inline-block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

/* Change color on hover */
.topnav a:hover {
  background-color:black;
  color: white;
}
.topnav input[type=text] {
  float: right;
  padding: 6px;
  border: none;
  margin-top: 8px;
  margin-right: 16px;
  font-size: 17px;
/* Style the content */
.content a{
  float: center;
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}
.content a:hover {
  background-color: #333;
  color: blue;
  text-align: center;
  }
/* Style the footer */
.footer {
  background-color: white;
 height: 200px;
}
 .rosine{
        background-color: #ffeecc;
        color: white;
        font-size: 17px;
        text-align:justify;
        border: 0;
        border-radius: 4px;
  }
	.welcome 
	{
		position: relative;
		text-align: center;			
	}
  #rose{
    font-size: 24px;
  
  }
	
</style>
<body>
 <div class="topnav">
  <a href="home1.php">HOME</a>
  <a href="book.php">book</a>
  <a href="contact us.php">contact us</a>
  <a href="policies and terms.php">policies and terms</a>
  <a href="login.php">Admin</a>
	 <a href="user.php">login</a>
  <a href="image.php">image</a>
  <a href="price_and_duration.php">price and duration</a>
	</div><center>
  <div class="welcome" style="background-color: blue; height: 40px;">
   <font color="white" size="16px"><h6>WELOME TO THOUSAND HILLS BEST EXPRESS</h6></font>
	</div>
	</center>
   <table class="rosine">
     <tr>
 <div> <font color="red"size="7px"></div>
  <a href="login.php">login here</a></th>
  <marquee>
  <img src="call.jpg" style="width:50%">
  <img src="modo.jpg" style="width:100%">
 <tr></tr><table>
 <img src="code.jpg" style="width:100%"> <table>
 </table>
 <div class="footer">
  <p> 2021 Copyright/allright reserved/VOLCANO RWANDA </p>
</body>
</html>

