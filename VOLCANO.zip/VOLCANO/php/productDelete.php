<?php
  include("config.php");
  $id =$_GET['id'];
  
  $query = "DELETE FROM product WHERE id=".$id;
  //echo $query;
  
  $r = mysqli_query($connection, $query);
  
  if($r){
	  echo "Product Delected";
  }else{
	  echo "Something went wrong!";
  }

?>