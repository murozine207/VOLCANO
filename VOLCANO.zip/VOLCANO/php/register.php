<?php 
include("../Config/db.php");

if(isset($_POST['iyandikishe'])){
  include './crud_class_file.php';
  $member = new CrudMembers();
  $result = $member->CreateMember($_POST);
}

?>




<!doctype html>
<html lang="en">

<head>
<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Responsive Web UI Kit Dashboard based on Bootstrap">
	<meta name="author" content="Gustave">
	<meta name="keywords" content="Gustave, php, js, css, html">

	<link rel="shortcut icon" href="./assets/img/ibiminalogo2.png" />

	<link href="assets/css/app.css" rel="stylesheet">
  <title>M-Ibimina::Registration</title>
</head>

<body>
	<div class="wrapper">
<style>
form label{
  font-size: 12px;
  font-weight: 700px;
}
input[type="text"],input[type="email"],input[type="date"],input[type="password"],input[type="number"]{
  height: 25px!important;
  font-size: 13px;
  font-weight: 500px;
}
#sele{
  height: 25px !important;
  font-size: 13px;
  font-weight: 500px;
}
.input-group-prepend{
  height: 25px!important;
  text-align: 'left'!important;
}
</style>
  <div class="main">

  <main class="content">
    <div class="container-fluid p-0">

      <div class="row mb-2 mb-xl-3">

        <div class="col-auto ml-auto text-right mt-n1">
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb bg-transparent p-0 mt-1 mb-0">
              <li class="breadcrumb-item"><a href="../">M-Ibimina</a></li>
              <li class="breadcrumb-item active" aria-current="page">Registration</li>
            </ol>
          </nav>
        </div>
      </div>

      <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">
          <div class="card">
            <div class="card-header">
            <?php
                if(isset($result)){
                  echo "<div class='alert alert-info alert-dismissable alert-sm' role='alert'>
                          <div class='alert-icon'>
                          <i class='far fa-fw fa-bell'></i>
                          </div>
                          <div class='alert-message'>
                          <strong>Great!</strong> $result!
                          </div>
                          <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                            <span aria-hidden='true'>&times;</span>
                          </button>
                        </div>";
                      }
                ?>
              <h5 class="card-title">Muraho,</h5>
              <h6 class="card-subtitle text-muted"><span>Biratwara umwanya <span class="text-success">muto cyane</span> kuba umunyamuryango</span>.</h6>
            </div>
            <div class="card-body">
              <form action="" method="post" onsubmit="return ValidateRegister()">
                <div class="col-md-12">
                  <div class="row">
                    <div class="col-md-4">
                    <label class="form-label">Lastname</label>
                      <div class="position-relative input-group form-group">
                        <div class="input-group-prepend">
                          <div class="input-group-text">
                            <i class="fa fa-user"></i>
                          </div>
                        </div>
                        <input type="text" class="form-control"
                          placeholder="Izina ryawe" name="firstname" id="firstname" >
                      </div>
                      <small id="fname" class="text-danger"></small>
                    </div>
                    <div class="col-md-4">
                      <label class="form-label">Middle Name (<small>If any</small>)</label>
                      <div class="position-relative input-group form-group">
                        <input type="text" class="form-control"
                          placeholder="Andi mazina" id="middlename" name="middlename">
                      </div>
                    </div>
                    <div class="col-md-4">
                      <label class="form-label">Surname</label>
                      <div class="position-relative input-group form-group">
                        <input type="text" class="form-control"
                          placeholder="Andi mazina" id="lastname" name="lastname" >
                      </div>
                      <small id="lname" class="text-danger"></small>
                    </div>
                  </div>
                </div>
                
                <div class="col-md-12">
                  <div class="row">
                    
                    <div class="col-md-7">
                      <label class="form-label">*Email</label>
                      <div class="position-relative input-group form-group">
                        <div class="input-group-prepend">
                          <div class="input-group-text">
                          <i class="align-middle mr-2" data-feather="at-sign"></i>
                          </div>
                        </div>
                        <input type="email" name="email" class="form-control"
                           placeholder="Shyiramo Imeyili" id="email" >
                      </div>
                      <small id="infos" class="text-danger"></small>
                    </div>
                    <div class="col-md-5">
                      <label class="form-label">*Genger</label>
                      <div class="position-relative input-group form-group sele">
                        <select name="gender" id="sele" class="form-control" >
                          <option value="" selected hidden>Select</option>
                          <option value="Male">Male</option>
                          <option value="Female">Female</option>
                        </select>
                      </div>
                      <small id="gender" class="text-danger"></small>
                    </div>
                    
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="row">
                    <div class="col-md-4">
                    <label class="form-label">Country</label>
                      <div class="position-relative input-group form-group">
                        <div class="input-group-prepend">
                          <div class="input-group-text">
                            <i class="align-middle mr-2" data-feather="home"></i>
                          </div>
                        </div>
                        <input type="text" class="form-control" 
                          placeholder="Igihugu ...." name="country" id="country" >
                      </div>
                      <small id="pay" class="text-danger"></small>
                    </div>
                    <div class="col-md-4">
                    <label class="form-label">City</label>
                      <div class="position-relative input-group form-group">
                        <div class="input-group-prepend">
                          <div class="input-group-text">
                            <i class="align-middle mr-2" data-feather="shield"></i>
                          </div>
                        </div>
                        <input type="text" class="form-control"
                          placeholder="Umujyi ...." id="city" name="city" >
                      </div>
                      <small id="town" class="text-danger"></small>
                    </div>
                    <div class="col-md-4">
                    <label class="form-label">Date of Birth</label>
                      <div class="position-relative input-group form-group">
                        <input type="date" class="form-control" id="birth_date" name="birth_date" >
                      </div>
                      <small id="dob" class="text-danger"></small>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="row">
                    <div class="col-md-6">
                      <label class="form-label">*Phone N<sup>o</sup></label>
                      <div class="position-relative input-group form-group">
                        <div class="input-group-prepend">
                          <div class="input-group-text">+250</div>
                        </div>
                        <input type="number" name="phone" class="form-control"
                           placeholder="Shyiramo phone ...." id="check_phone" >
                      </div>
                      <small id="phone_msg" class="text-danger"></small>
                    </div>
                    <div class="col-md-6">
                      <label class="form-label">*Professional/Job</label>
                      <div class="position-relative input-group form-group">
                        <input type="text" name="profession" class="form-control"
                           placeholder="Icyo ukora ...." id="profession" >
                      </div>
                      <small id="pro" class="text-danger"></small>
                    </div>
                  </div>
                 
                </div>
                <div class="col-md-12">
                  <div class="row">
                    <div class="col-md-6">
                      <label class="form-label">*Password</label>
                      <div class="position-relative input-group form-group">
                        <div class="input-group-prepend">
                          <div class="input-group-text">
                            <i class="fa fa-unlock-alt"></i>
                          </div>
                        </div>
                        <input name="password" id="inputPasswordNew" placeholder="Password here..." type="password"
                          class="form-control" name="password">
                      </div>
                      <small id="pwd" class="text-danger"></small>
                    </div>
                    <div class="col-md-6">
                      <label class="form-label">*Retype password</label>
                      <div class="position-relative input-group form-group">
                        <div class="input-group-prepend">
                          <div class="input-group-text">
                            <i class="fa fa-unlock-alt"></i>
                          </div>
                        </div>
                        <input name="confirm_password" id="inputPasswordNew2" placeholder="Repeat Password here..."
                          type="password" class="form-control" >
                      </div>
                      <small id="cpwd" class="text-danger"></small>
                    </div>
                    <small id="check"></small>
                  </div>

                </div>
                  <!-- show password -->
                  <div class="col-md-12">
                    <div class="form-row" style="padding: 0px 0px 12px 08px">
                      <div class="position-relative form-check">
                        <input onclick="ShowPassword();" type="checkbox" class="form-check-input">&nbsp;
                        <small for="ShowPassword" class="form-check-label">Show passwords</small>
                      </div>
                    </div>
                  </div>
                  <!-- End show -->
                <div class="col-md-12">
                  <div class="mt-3 position-relative form-check">
                    <input id="agree" name="agree" value="agree" type="checkbox" class="form-check-input" required>
                    <label for="agree" class="form-check-label">
                      Emeza, Soma <a href="javascript:void(0);" data-toggle="modal" data-target="#myModal">Amategeko n'amabwira atugenga</a>.
                    </label>
                  </div>
                </div>

                <br>
                <button class="btn-wide btn-pill btn-shadow btn-hover-shine btn btn-primary btn-block" type="submit" name="iyandikishe" id="update_pass">Iyandikishe</button>

              </form>
                <br>
                <div class="col-md-12">
                  <div class="row">
                    <div class="col-md-6">
                      <h6 class="mb-0">Niba usanzwe Wanditse?</h6>
                    </div>
                    <div class="col-md-6">
                      <a href="./login" class="text-primary">Injira</a> | <a href="../" class="text-primary">Subira Inyuma</a>
                    </div>
                  </div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
  
  <?php include('./layout/foot.php'); ?>

</div>
<?php include("./layout/footer.php"); ?>

<script>
// Show passwords
let inputPasswordNew = document.getElementById('inputPasswordNew');
let inputPasswordNew2 = document.getElementById('inputPasswordNew2');

function ShowPassword(){
  if (inputPasswordNew.type === "password" && inputPasswordNew2.type === "password"){
    inputPasswordNew.type = "text";
    inputPasswordNew2.type = "text";
		// console.log("changed");
  }else{
    inputPasswordNew.type = "password";
    inputPasswordNew2.type = "password";
  }
}
</script>
<!-- terms and condition modal -->
<style>
.modal-body {
    max-height: calc(100vh - 100px);
    overflow-y: auto;
}
#mhead{
  text-transform: uppercase;
}
</style>
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content" style="background-color: rgb(188,172,142);">
    <!-- <div class="modal-header">
        <h4 class="modal-title">Amategeko n'amabwiriza</h4>
      </div> -->
      <div class="modal-body">
      <h4 id="mhead"><b><center>Amategeko n'amabwiriza</center></b></h4>
        <h5>1. Ibibujijwe</h5>
        <p>
          Ntugomba gukoresha nabi uru rubuga. Irinde gukora icyaha cyikoranabuhanga 
          nko kohereza cyangwa gukwirakwiza virusi iyo ari yo yose ya mudasobwa cyangwa ibindi bikoresho byose bishobora kwangiza 
          seriveri(servers) zacu, Kugerageza muburyo ubwo aribwo bwose bwo kwinjira serivisi zacu byatuma amakuru yangirika; 
          Kohereza amafoto, amashusho cyangwa ubutuma byurukozasoni; kwamamaza bidasabiye uburenganzira;
          cyangwa kugerageza guhindura imikorere ya mudasobwa z'abandi bakoresha byinjira binyuze kuri uru rubuga. 
        </p>
        <h5>2. Politiki Yibanga</h5>
        <p>Politiki y’ibanga yacu, igaragaza uburyo tuzakoresha amakuru yawe, murayasanga kuri www.m-ibimina.com Ukoresheje Uru Rubuga, 
        wemera gutunganya ibyasobanuwe muriyo kandi ukemeza ko amakuru yose yatanzwe ari ukuri.
        </p>
        <h5>3. Andi mategeko</h5>
        <p>
          Uburenganzira bwose bubitswe na www.m-ibimina.com nababifitemo uruhushya. Urashobora kubika, gucapa no kwerekana ibikubiyemo bitangwa gusa kubikoresha wenyine. 
          Ntabwo wemerewe gutangaza, kuyobora muburyo ubwo aribwo bwose kopi yibirimo kuguha cyangwa kugaragara kururu rubuga 
          kandi ntushobora gukoresha uru rubuga nkibi guhuza nubucuruzi ubwo aribwo bwose bwawe.
        </p>
        <h5>4. Icyitonderwa</h5>
        <p>
          Kurenga kuri iyi ngingo bihanwa n'amategeko kandi www.m-ibimina.com 
          izamenyesha amakosa yose nkaya inzego zibishinzwe kubahiriza amategeko no kubamenyesha umwirondoro wawe
        </p>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
    </div>

  </div>
</div>
<!-- End of modal -->