<?php
  include("config.php");
?>

<form action="" method="post">
  <input type="text" name ="pname" placeholder="Enter the product name"/>
  <br/> 
    <input type="number" name ="price" placeholder="Enter the price"/>
   <br/> 
	<input type="submit" name ="submit" value="Save"/>
	<input type="submit" name ="retrieve" value="Retrieve"/>
</form>
<?php
   if(isset($_POST["submit"])){
	    $name = $_POST['pname'];
		$price = $_POST['price'];
		
		$query= "INSERT INTO product (id, pname, pprice)
		VALUES ('','$name',$price)";
		
		$r = mysqli_query($connection, $query); 
	    if(!$r){
			echo "Failed ".mysqli_error($connection);
		}else{
			echo "Product saved";
		}
   }else{
	   
	   $rqu = "SELECT * FROM product";
	   $result = mysqli_query($connection, $rqu);
	   ?>
	   <table border="1">
	     <tr>
		    <th>ID </th>
			<th>Product name </th>
			<th>Product price </th>
		</tr> 
	   <?php
	   while($r = mysqli_fetch_array($result)){
		   
		    echo "<tr><td>".$r['id']."</td><td>".$r['pname']."</td><td>".$r['pprice']."</td><tr>";
	        
	   }
	   echo "</table>";
   }

?>
