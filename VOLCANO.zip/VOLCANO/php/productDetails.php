<?php
   include("config.php");
   $id = $_GET['id'];
   $query = "SELECT * FROM product WHERE id =".$id;
   
   $result = mysqli_query ($connection, $query);
   if(!$result){
	   echo "Error ".mysqli_error($connection);
   }else{
	   while($row=mysqli_fetch_array($result)){
		    echo "<br/><hr/>";
		   echo "Product ID: ".$row['id']; echo "<br/>";
		   echo "Product Name: ".$row['pname']; echo "<br/>";
		   echo "Product Price: ".$row['pprice']; echo "<br/>";
	   }
   }
?>