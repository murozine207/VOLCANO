<?php
include './configurations/db.php';

class CrudMembers extends Dbh{
  // Insert Member in Db
  public function CreateMember(){
    $firstname = htmlspecialchars(strip_tags($_POST['firstname']));
    $middlename = htmlspecialchars(strip_tags($_POST['middlename']));
    if(empty($middlename)){
      $lastname = htmlspecialchars(strip_tags($_POST['lastname']));
    }else{
      $lastname = $middlename.' '.htmlspecialchars(strip_tags($_POST['lastname']));
    }
    $email = htmlspecialchars(strip_tags($_POST['email']));
    $gender = htmlspecialchars(strip_tags($_POST['gender']));
    $country = htmlspecialchars(strip_tags($_POST['country']));
    $city = htmlspecialchars(strip_tags($_POST['city']));
    $birth_date = htmlspecialchars(strip_tags($_POST['birth_date']));
    $profession = htmlspecialchars(strip_tags($_POST['profession']));
    $phone = '250'.htmlspecialchars(strip_tags($_POST['phone']));
    $pass = htmlspecialchars(strip_tags($_POST['password']));
    $password = password_hash($pass, PASSWORD_DEFAULT);
    //$code=substr(md5(mt_rand()),0,15);
    $code = rand(10, 2000);
    
    // Check if email is taken or avaiable In Ajax
    try{
      // $sql = "INSERT INTO users (firstname,lastname,email, phone, password, code) 
      //         VALUES (:firstname,:lastname,:email, :phone, :password, :code)";
      $sql = "INSERT INTO members (firstname,lastname,email, gender, country, city,birth_date,profession, phone, password) 
              VALUES (:firstname,:lastname,:email,:gender, :country, :city,:birth_date,:profession, :phone, :password)";
      $stmt = $this->connect()->prepare($sql);
      $stmt->bindParam(':firstname', $firstname);
      $stmt->bindParam(':lastname', $lastname);
      $stmt->bindParam(':email', $email);
      $stmt->bindParam(':gender', $gender);
      $stmt->bindParam(':country', $country);
      $stmt->bindParam(':city', $city);
      $stmt->bindParam(':birth_date', $birth_date);
      $stmt->bindParam(':profession', $profession);
      $stmt->bindParam(':phone', $phone);
      $stmt->bindParam(':password', $password);
      // $stmt->bindParam(':code', $code);
      $stmt->execute();
      
      
      if($stmt->rowCount()==1){
        $id = $this->connect()->lastInsertId();
        $to=$email;
        $time = time();
        $subject="Emeza konte yawe M-ibimina";
        $from = 'M-ibimina';
        $headers = "MIME-Version: 1.0\r\n";
        $headers = "Content-Type: text/html; charset=UTF-8\r\n";
        $headers .= 'From: '.$from."\r\n".'Reply-To: '.$from."\r\n".'X-Mailer: PHP/' . phpversion();
        $message = '<html><body>';
        $message = "<center>";
        $message = "<h3>Muraho $firstname,";
        $message = "Twizeye ko iyi imeri isanze umeze neza</h3>";
        $message .='<p>
                      Urakoze kuduhitamo!<br>
                      Nibisanzwe kwibagirwa ijambo ryibanga <br> 
                      Koresha iyi link kugirango ugarure ijambo ryibanga
                    </p>';
        $message .= '<a class="btn btn-primary btn-sm" href="'.$_SERVER['HTTP_HOST'].'/ibimina/members/verify.php?id='.$id.'&code='.$code.'">click here</a> ';
        $message .= '<p>
                      <br><br><br><br>
                      <small>
                        Subscribe to our News Letter 
                        (Kanda aha tuge tukumenyesha ibigezweho byose) 
                        <br>
                        <a class="btn btn-primary btn-sm" href="'.$_SERVER['HTTP_HOST'].'/ibimina/members/subscribe.php?id='.$id.'&code='.$code.'&email='.$email.'">subscribe</a> 
                      </small>
                    <p>';
        $message .= '<small>M-Ibimina Administrations</small>';
        $message = "</center>";
        $message .= '</body></html>';
        mail($to,$subject,$message,$headers);
  
        //echo "<script>alert('An Activation Code Is Sent To You Check You Emails');</script>";
        // $alert_class = "class='alert alert-success alert-dismissable alert-sm'";
        $result = "<small>Sura imeri yawe, twohereje ubutumwa bwo kwemeza</small>";
        // header("location: ./verify.php");
      }else{
        // $alert_class = "class='alert alert-danger alert-dismissable alert-sm'";
        $result = "<small>Nta konti yanditswe kuri iyi imeri</small>";
        //echo "<script>alert('not added');</script>";
      }
  }catch(PDOException $ex){
      $result = "<p>Error occured: ".$ex->getMessage()."</p>";
  }
  return $result;
  }


  // Login Function
  public function Login(){
    
    $attempt_member_id = $_SERVER['REMOTE_ADDR'];
    $number_of_attempt = 1;
    $email = htmlspecialchars(strip_tags($_POST['phone_email']));
    $phone = htmlspecialchars(strip_tags($_POST['phone_email']));
    $password = htmlspecialchars(strip_tags($_POST['password']));


    $sqlQuery = "SELECT * FROM members WHERE email = :email OR phone = :phone LIMIT 1";
    $statement = $this->connect()->prepare($sqlQuery);
    $statement->execute(
        array(
            ':email' => $email,
            ':phone' => $phone
        )
    );
    if($statement->rowCount() > 0){
      $row=$statement->fetch(PDO::FETCH_ASSOC);
      // Check password
      if(password_verify($password, $row['password'])){
        // Check if there is any login attempt in system and then remove
        $sqli = "SELECT * FROM login_attempt WHERE member_id = :member_id";
        $stmt_query = $this->connect()->prepare($sqli);
        $stmt_query->execute(
          array(
            ':member_id' => $attempt_member_id
            )
          );
        if($stmt_query->rowCount() > 0){
          $remove = "DELETE FROM login_attempt WHERE member_id = :member_id";
          $remove_attempt = $this->connect()->prepare($remove);
          $remove_attempt->execute(
            array(
              ':member_id' => $attempt_member_id
              )
            );
          }
          // end of Check if there is any login attempt in system

          // If user is in db
          $member_id = $row['member_id'];
          $password = $row['password'];
          $email = $row['email'];
          $_SESSION['login'] = true;
          $_SESSION['member_id']=$member_id;
          $_SESSION['email']=$email;


          $sqli = "SELECT `ibimina`.* FROM `ibimina` JOIN `ibiminaMembership` 
                  ON `ibimina`.`ikimina_id` = `ibiminaMembership`.`ibimina`
                  WHERE `ibiminaMembership`.`members` = $member_id";
          $stem = $this->connect()->query($sqli);
          $stem->execute();
          $is_member = $stem->rowCount();
          $response = $stem->fetch(PDO::FETCH_ASSOC);
          $ikimina_id = $response['ikimina_id'];

          if($is_member > 1){
            header("location: ./select_ikimina");
          }else{
            $msql = "SELECT * FROM ibimina WHERE ikimina_id=:ikimina_id";
            $mstmt = $this->connect()->prepare($msql);
            $mstmt->execute(
              array(
                ':ikimina_id' => $ikimina_id
              )
            );
            $row = $mstmt->fetch(PDO::FETCH_ASSOC);
            $_SESSION['ikimina_id']=$ikimina_id;
            header("location: ./");
          }
      }else{
        // $att = new Attempt();
        // $att->GetAttempt();
        $result = "<small>Ijambo banga ryanditswe nabi</small>";
      }

    }else{
      // $att = new Attempt();
      // $att->GetAttempt();
      $result = "<small>Nta konti yanditswe kuri iyi imeri</small>";
    }



    return $result;
  }


  // Create ikimina Function
  // public function CreateIkimina(){

  // }

}



?>