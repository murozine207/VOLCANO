<?php
 $server ="127.0.0.1";
 $con = mysqli_connect($server, "root","", "huyecse");
 
 if(!$con){
	 die("Connection failed!");
 }
  //echo "Success";
?>