﻿<?php

session_start();
include("../Config/db.php");

if(isset($_POST['loginBtn'])){
  include './crud_class_file.php';
  include './login_attempt.php';

  $member = new CrudMembers();
  $result = $member->Login($_POST);
  $att = new Attempt();
  $output = $att->GetAttempt($_POST);
}
    

?>

<!doctype html>
<html lang="en">

<head>
<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Responsive Web UI Kit Dashboard based on Bootstrap">
	<meta name="author" content="Gustave">
	<meta name="keywords" content="Gustave, php, js, css, html">

	<link rel="shortcut icon" href="./assets/img/ibiminalogo2.png" />

	<link href="assets/css/app.css" rel="stylesheet">
<title>M-ibimina:: Login</title>
</head>

<body>
	<div class="wrapper">
    <div class="main">

      <main class="content">
        <div class="container-fluid p-0">

          <div class="row mb-2 mb-xl-3">
            <div class="col-auto d-none d-sm-block">
              <small> <strong>Login</strong> Phase</small>
            </div>

            <div class="col-auto ml-auto text-right mt-n1">
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb bg-transparent p-0 mt-1 mb-0">
                  <li class="breadcrumb-item"><a href="#">M-Ibimina</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Login</li>
                </ol>
              </nav>
            </div>
          </div>
          <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-4">
              <form action="" method="POST" class="" id="signupForm">
                <div class="col-md-12">
             
                <?php if(isset($output)){ echo $output; } ?>
                  <h1 class="text-success">Login</h1>
                  <?php if(isset($_SESSION['restrict_user'])): ?>
                    <small class="text-danger">Login Button has been disabled due to more login trial</small><br>
                    <small class="text-danger">Login Again in an hour</small>
                  <?php endif ?>
                  <hr>
                  <?php if(isset($result)){
                    echo "<div class='alert alert-danger alert-dismissable alert-sm' role='alert'>
                            <div class='alert-icon'>
                            <i class='far fa-fw fa-bell'></i>
                            </div>
                            <div class='alert-message'>
                            <strong>Opps!</strong> $result!
                            </div>
                            <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                              <span aria-hidden='true'>&times;</span>
                            </button>
                          </div>";
                        }
                  ?>
                  
                  <label for="login" class=""><span class="text-danger">*</span>Imeyili cg Phone</label>
                  (<strong>Hint: </strong><small class="text-info text-right">Start phone with (250)</small>)
                  
                  <div class="position-relative input-group form-group">
                    <div class="input-group-prepend">
                      <div class="input-group-text">
                        <i class="fa fa-user"></i>
                      </div>
                    </div>
                    <input type="text" name="phone_email" class="form-control input-mask-trigger" im-insert="true"
                      required placeholder="Shyiramo Imeyili" id="phone_email" required>
                  </div>
                  
                  <span id="phone_email" class="text-info"></span>
                </div>

                <div class="col-md-12">
                  <label for="examplePassword" class=""><span class="text-danger">*</span>Password</label>
                  <div class="position-relative input-group form-group">
                    <div class="input-group-prepend">
                      <div class="input-group-text">
                        <i class="fa fa-unlock-alt"></i>
                      </div>
                    </div>
                    <input name="password" id="password" placeholder="Ijambo banga..." type="password"
                        class="form-control input-mask-trigger" im-insert="true" required>
                  </div>
                </div>
                <?php if(isset($_SESSION['restrict_user'])): ?>
                  <div class="col-md-12">
                    <div class="d-flex align-items-center">
                      <div class="ml-auto">
                        <small class="text-info">Wongere ugerageze nyuma yisaha</small>
                        <button class="btn btn-danger btn-sm" disabled>Konti Yahagaritswe</button>
                      </div>
                    </div>
                  </div>
                <?php else: ?>
                  <div class="col-md-12">
                    <div class="d-flex align-items-center">
                      <div class="ml-auto">
                        <a href="./forgot-password" class="btn-lg btn btn-link"><small>Garura ijambo ry'ibanga</small></a>
                        <button class="btn btn-primary btn-sm" type="submit" name="loginBtn" id="loginBtn">Injira</button>
                      </div>
                    </div>
                  </div>
                <?php endif ?>

                <div class="col-md-12">
                  <hr>
                  <a href="./register">New Account?</a>
                </div>
                <!-- <div id="demo"></div> -->
              </form>

              
            </div>
          </div>

        </div>
      </main>
      
      <?php include('./layout/foot.php'); ?>

    </div>

<?php include("./layout/footer.php"); ?>