<?php
 
$host="localhost";
$username="root";
$password="";
$dbname="application";

$conn=mysqli_connect($host,$username,$password,$dbname);

$username=$_POST['usename'];
$email=$_POST['Email'];
$password=$password_POST['  pwd'];

 if( empty($username)|| empty($email)|| empty($pwd))
 {
     header("location:signup.html");
     exit();
 }
 else{
     $sql="INSERT INTO success(username,Email,pwd") value('$username','$Email','$pwd');
     mysqli_quel($conn,$sql);
     header("location:index.php");
     exit();
 }