<?php

// Create connection
$conn = new mysqli('localhost', 'root', '', 'volcano');
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM driver";

$result = mysqli_query($conn, $sql);
 echo "<table border=1 ><tr><td width=2% > " . "<b>driver_id</B>". " </td><td width=4% > " . "<b>driver_name</B>". " </td><td width=4% >" . "<b>driver_contact</B>". "</td><td width=3%> "."<b>user_id</b>"."</td></tr></table>";
	  

$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "<table border=1 ><tr><td width=2% > " . $row["driver_id"]. " </td><td width=4%> " . $row["driver_name"]. " </td><td width=4%>" . $row["driver_contact"]. "</td><td width=3%> " . $row["user_id"]." </td></tr></table>";
	  
  }
} else {
  echo "0 results";
}
$conn->close();
?>