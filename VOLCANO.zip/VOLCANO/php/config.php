<?php
      $server ="127.0.0.1";
   $user ="root";
   $pass ="";
   $db ="huyecse";
   
   $connection = mysqli_connect($server,$user, $pass,$db);
   
   if(!$connection){
	   echo "Not passing ";
   }else{
	   echo "Passed";
   }
?>