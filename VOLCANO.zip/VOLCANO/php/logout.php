<?php 
session_start();
include("../Config/db.php");

if(isset($_SESSION['member_id'])){
  session_destroy();
  header('location: ./index');
}else{
  header('location: ./login');
}
?>