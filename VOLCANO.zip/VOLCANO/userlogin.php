

<?php
include("db_connect.php");


$username=$_POST["username"];
$password=$_POST["password"];


if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

else{
	$stmt=$conn->prepare("select * from customer where email=? AND password=? ");
	$stmt->bind_param("ss",$username,$password);
	$stmt->execute();
	$stmt_result=$stmt->get_result();
	if($stmt_result->num_rows>0){
		$data=$stmt_result->fetch_assoc();
		
             
		header("location:../form/customer.php");
		
	
			
	
}
	else{
		header("location:../form/user.php");
		
	}

}

?>